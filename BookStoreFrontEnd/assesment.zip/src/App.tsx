import MainPage from './pages/MainPage';
import Login from './pages/Login';
import Register from './pages/Register';
import { Routes, Route, Navigate } from 'react-router-dom';

function App() {
  const jwtToken = localStorage.getItem('jwt');

  return (
    <Routes>
      {jwtToken ? (
        <Route path="/" element={<Navigate to="/books" />} />
      ) : (
        <Route path="/" element={<Login />} />
      )}
      <Route path="/register" element={<Register />} />
      <Route path="/books" element={<MainPage />} />
    </Routes>
  );
}

export default App;
