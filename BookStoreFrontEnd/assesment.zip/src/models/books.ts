import { Book } from './book';

export interface Books {
  booksData: [Book];
}
