import { ThunkAction, ThunkDispatch } from 'redux-thunk';
import { AnyAction } from 'redux';
import { RootState } from '../reducers';
import {
  BookActionTypes,
  FETCH_BOOKS_REQUEST,
  FETCH_BOOKS_SUCCESS,
  FETCH_BOOKS_FAILURE,
  FETCH_BOOKS_UNAUTHORIZED
} from './bookActionTypes';
import axios, { AxiosError } from 'axios';
import { Book } from '../../models/book';

export const fetchBooksRequest = (): BookActionTypes => ({
  type: FETCH_BOOKS_REQUEST
});

export const fetchBooksSuccess = (books: Book[], totalPages: number): BookActionTypes => ({
  type: FETCH_BOOKS_SUCCESS,
  payload: { books, totalPages }
});

export const fetchBooksFailure = (error: string): BookActionTypes => ({
  type: FETCH_BOOKS_FAILURE,
  payload: error
});

export const fetchBooksUnAuthorized = (errorCode: number): BookActionTypes => ({
  type: FETCH_BOOKS_UNAUTHORIZED,
  payload: { errorCode }
});

export const fetchBooks =
  (pageNumber: number, jwtToken: string): ThunkAction<void, RootState, unknown, AnyAction> =>
  async (dispatch: ThunkDispatch<RootState, unknown, AnyAction>) => {
    dispatch(fetchBooksRequest());
    try {
      const response = await axios.get(
        `http://localhost:3001/api/books?page=${pageNumber}&limit=10`,
        { headers: { Authorization: jwtToken } }
      );
      dispatch(fetchBooksSuccess(response.data.books, response.data.totalPages));
    } catch (error) {
      // Handle Axios error here
      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError; // You can also use 'as AxiosError<any>' if you don't know the response data type
        dispatch(fetchBooksUnAuthorized(axiosError.response?.status ?? 0));
      } else {
        dispatch(fetchBooksFailure('Error fetching books data.'));
      }
    }
  };
